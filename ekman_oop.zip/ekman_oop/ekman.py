"""A small, restartable 1D Ekman model for assimilation experiments."""

from copy import deepcopy
from dataclasses import dataclass
from math import floor, inf, isfinite

import numpy as np
import xarray as xr


@dataclass(frozen=True)
class EkmanConfig:
    nz: int = 100
    lz: float = 500.0
    fcor: float = 1e-4
    dt_max: float = 5.0
    spinup_seconds: float = 60 * 3600
    output_interval: float = 60.0


@dataclass
class ModelState:
    u: np.ndarray
    v: np.ndarray
    time: float
    timestep: int
    ug: float
    vg: float
    K: float


class Ekman:
    """Integrates the Ekman equations; knows nothing about assimilation or I/O."""

    def __init__(self, ug=10.0, vg=0.0, K=2.0, config=None):
        self.config = config or EkmanConfig()
        c = self.config
        if c.nz < 2 or c.lz <= 0 or c.dt_max <= 0 or c.spinup_seconds < 0:
            raise ValueError("Invalid grid or time configuration")
        if c.output_interval <= 0 or not all(isfinite(x) for x in (ug, vg, K, c.fcor, c.lz, c.dt_max, c.output_interval)) or K <= 0:
            raise ValueError("Invalid wind, diffusivity, or model configuration")
        self.z = np.linspace(0, c.lz, c.nz + 1)
        self.dz = c.lz / c.nz
        self.state = ModelState(
            u=ug * self.z / c.lz,
            v=np.full(c.nz + 1, vg, dtype=float),
            time=0.0, timestep=0, ug=float(ug), vg=float(vg), K=float(K),
        )
        self.apply_boundaries()

    @property
    def dt(self):
        return min(0.45 * self.dz**2 / self.state.K, self.config.dt_max)

    def apply_boundaries(self):
        s = self.state
        s.u[0], s.v[0] = 0.0, 0.0
        s.u[-1], s.v[-1] = s.ug, s.vg

    def tendencies(self):
        s = self.state
        diffusion_u = s.K * (s.u[2:] - 2 * s.u[1:-1] + s.u[:-2]) / self.dz**2
        diffusion_v = s.K * (s.v[2:] - 2 * s.v[1:-1] + s.v[:-2]) / self.dz**2
        du = diffusion_u + self.config.fcor * (s.v[1:-1] - s.vg)
        dv = diffusion_v - self.config.fcor * (s.u[1:-1] - s.ug)
        return du, dv

    def step(self, dt=None):
        dt = self.dt if dt is None else dt
        if dt <= 0 or dt > self.dt * (1 + 1e-12):
            raise ValueError("Time step must be positive and stable")
        du, dv = self.tendencies()  # Both use the OLD velocity fields.
        self.state.u[1:-1] += dt * du
        self.state.v[1:-1] += dt * dv
        self.state.time += dt
        self.state.timestep += 1

    def integrate(self, until):
        if until < self.state.time:
            raise ValueError("Cannot integrate backwards")
        while self.state.time < until - 1e-10:
            self.step(min(self.dt, until - self.state.time))
        self.state.time = float(until)

    def spin_up(self):
        """Spin up the model, then reset the clock to time zero."""
        if self.state.time != 0:
            raise ValueError("Spin-up must precede the forecast")
        self.integrate(self.config.spinup_seconds)
        self.state.time = 0.0
        self.state.timestep = 0

    def snapshot(self):
        return deepcopy(self.state)

    def restore(self, state):
        self.state = deepcopy(state)
        self.apply_boundaries()

    def copy(self):
        return deepcopy(self)


@dataclass
class StateUpdater:
    """Apply prescribed wind increments and/or replace model parameters."""

    ug: float | None = None
    vg: float | None = None
    K: float | None = None
    du: float = 0.0
    dv: float = 0.0
    h_obs: float | None = None
    sigma: float | None = None

    def apply(self, model):
        s = model.state
        if self.K is not None and (not isfinite(self.K) or self.K <= 0):
            raise ValueError("Updated K must be positive and finite")
        if not all(isfinite(x) for x in (self.du, self.dv)):
            raise ValueError("Wind increments must be finite")
        if self.ug is not None and not isfinite(self.ug):
            raise ValueError("Updated ug must be finite")
        if self.vg is not None and not isfinite(self.vg):
            raise ValueError("Updated vg must be finite")
        if self.du != 0 or self.dv != 0:
            if self.h_obs is None or self.sigma is None or not isfinite(self.sigma) or self.sigma <= 0:
                raise ValueError("Wind increments require h_obs and positive sigma")
            if not 0 <= self.h_obs <= model.config.lz:
                raise ValueError("h_obs must be within the model domain")
            weights = np.exp(-0.5 * ((model.z[1:-1] - self.h_obs) / self.sigma)**2)
            s.u[1:-1] += self.du * weights
            s.v[1:-1] += self.dv * weights
        if self.ug is not None:
            s.ug = float(self.ug)
        if self.vg is not None:
            s.vg = float(self.vg)
        if self.K is not None:
            s.K = float(self.K)
        model.apply_boundaries()


class Simulation:
    """Schedule updates, record profiles, and branch independent forecasts."""

    def __init__(self, model):
        self.model = model
        self.events = {}       # {time: [StateUpdater, ...]}
        self.history = [model.snapshot()]
        self.analyses = {}     # {time: {'background': state, 'analysis': state}}

    def schedule(self, time, update):
        if time < self.model.state.time - 1e-9:
            raise ValueError("Cannot schedule an update in the past")
        self.events.setdefault(float(time), []).append(update)
        return self

    def copy(self):
        """Independent branch including checkpoint, history, and planned updates."""
        return deepcopy(self)

    def _record(self):
        state = self.model.snapshot()
        if abs(self.history[-1].time - state.time) < 1e-9:
            self.history[-1] = state   # analysis replaces prior at the same time
        else:
            self.history.append(state)

    def _apply_updates(self):
        t = self.model.state.time
        events = [when for when in self.events if abs(when - t) < 1e-9]
        for when in events:
            prior = self.model.snapshot()
            for update in self.events.pop(when):
                update.apply(self.model)
            self.analyses[when] = {
                "background": prior, "analysis": self.model.snapshot()
            }
            self._record()
        return bool(events)

    def run(self, until):
        """Integrate to `until`, recording full profiles on exact output times."""
        if not isfinite(until) or until < self.model.state.time - 1e-9:
            raise ValueError("End time must be finite and not in the past")
        self._apply_updates()
        interval = self.model.config.output_interval
        while self.model.state.time < until - 1e-9:
            t = self.model.state.time
            next_output = (floor((t + 1e-9) / interval) + 1) * interval
            next_event = min((x for x in self.events if x > t + 1e-9), default=inf)
            target = min(float(until), next_output, next_event)
            dt = min(self.model.dt, target - t)
            self.model.step(dt)
            if abs(self.model.state.time - target) < 1e-9:
                self.model.state.time = target
            updated = self._apply_updates()
            if updated or abs(self.model.state.time - next_output) < 1e-9 or abs(self.model.state.time - until) < 1e-9:
                self._record()
        return self.dataset()

    def dataset(self):
        """Return full velocity profiles as an xarray.Dataset."""
        states = self.history
        coords = {
            "time": ("time", [s.time for s in states]),
            "z": ("z", self.model.z),
            "timestep": ("time", [s.timestep for s in states]),
        }
        for name, field in (("u_g", "ug"), ("v_g", "vg"), ("K", "K")):
            values = np.array([getattr(s, field) for s in states])
            coords[name] = float(values[0]) if np.all(values == values[0]) else ("time", values)
        ds = xr.Dataset(
            {"u": (("time", "z"), np.stack([s.u for s in states])),
             "v": (("time", "z"), np.stack([s.v for s in states]))},
            coords=coords,
            attrs={"fcor": self.model.config.fcor,
                   "output_interval_seconds": self.model.config.output_interval,
                   "spinup_seconds": self.model.config.spinup_seconds},
        )
        for name, units in {"time": "s", "z": "m", "u": "m s-1", "v": "m s-1",
                            "u_g": "m s-1", "v_g": "m s-1", "K": "m2 s-1"}.items():
            ds[name].attrs["units"] = units
        return ds


def _error(forecast, reference):
    """Require identical coordinates rather than silently aligning by intersection."""
    forecast, reference = xr.align(forecast, reference, join="exact")
    return forecast - reference


def rmse(forecast, reference, dim=None):
    return np.sqrt((_error(forecast, reference)**2).mean(dim=dim))


def bias(forecast, reference, dim=None):
    return _error(forecast, reference).mean(dim=dim)


def mae(forecast, reference, dim=None):
    return abs(_error(forecast, reference)).mean(dim=dim)


def vector_rmse(forecast, reference, dim=None):
    return np.sqrt((_error(forecast.u, reference.u)**2 +
                    _error(forecast.v, reference.v)**2).mean(dim=dim))
